<?php

namespace Mage4\Inquiry\Block;

use Mage4\Inquiry\Model\ResourceModel\Item\CollectionFactory;
use Magento\Framework\View\Element\Template;

class InquiryForm extends Template
{
    private $activitiesOptions;
    private $occupationOptions;
    private $collectionFactory;

    public function __construct(
        Template\Context $context,
        CollectionFactory $collectionFactory,
        \Mage4\Inquiry\Model\Source\OccupationOptions $occupationOptions,
        \Mage4\Inquiry\Model\Source\ActivitiesOptions $activitiesOptions,
        array $data = []
    )
    {
        $this->collectionFactory = $collectionFactory;
        $this->occupationOptions = $occupationOptions;
        $this->activitiesOptions = $activitiesOptions;
        parent::__construct($context, $data);
    }

    /**
     * @return \Mage4\Inquiry\Model\Item[]
     */

    public function getOccupationOptions()
    {
        return $this->occupationOptions->getOptions();
    }
    public function getActiviitesOptions(){
        return $this->activitiesOptions->getOptions();
    }
    public function getItems()
    {
        return $this->getUrl('inquiry/index/save', ['_secure' => true]);
    }
}
